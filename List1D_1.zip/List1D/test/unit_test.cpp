
#include "unit_test.hpp"

map<string, function<bool()>> UNIT_TEST::TESTS;