#include "KTLT_string.h"

string runLengthEncoding(const string &s) { return ""; }