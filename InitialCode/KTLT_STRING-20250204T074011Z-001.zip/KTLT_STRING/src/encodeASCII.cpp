#include "KTLT_string.h"

string encodeASCII(const string &s, int k) { return ""; }