#include "KTLT_string.h"

string removeConsecutiveDuplicates(const string &s) { return ""; }