#include "KTLT_string.h"

bool isPalindrome(const string &s) { return true; }