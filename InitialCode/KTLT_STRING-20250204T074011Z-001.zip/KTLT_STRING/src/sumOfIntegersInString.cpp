#include "KTLT_string.h"

int sumOfIntegersInString(const string &s) { return 0; }