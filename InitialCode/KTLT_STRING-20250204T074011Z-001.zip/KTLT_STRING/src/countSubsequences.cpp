#include "KTLT_string.h"

long long countSubsequences(const string &S, const string &P) { return 0; }