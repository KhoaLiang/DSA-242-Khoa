#ifndef PETHOTEL_H
#define PETHOTEL_H

#include <iostream>
#include <sstream>
#include <string>

#include "Animal.h"
#include "Cat.h"
#include "Dog.h"

class PetHotel {};

#endif  // PETHOTEL_H
