#ifndef DOG_H
#define DOG_H

#include "Animal.h"

class Dog : public Animal {};

#endif  // DOG_H
