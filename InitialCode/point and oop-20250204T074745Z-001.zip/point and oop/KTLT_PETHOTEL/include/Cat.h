#ifndef CAT_H
#define CAT_H

#include "Animal.h"

class Cat : public Animal {};

#endif  // CAT_H
