#include "../unit_test_KTLT_petHotel.hpp"

bool UNIT_TEST_KTLT_petHotel::petHotel02() {
    string name = "petHotel02";
    stringstream output; // Đảm bảo output được lưu vào dòng

    PetHotel hotel(3, 3);

    // Create some pets
    Animal* dog1 = new Dog("Buddy", "2025-01-10");
    Animal* cat1 = new Cat("Mia", "2025-01-11");

    // Case 1: Invalid position (-1, 0)
    string result1 = hotel.addAnimal(dog1, -1, 0);
    output << "Case 1 (Invalid position): " << result1 << std::endl;

    // Case 2: Successfully add (0, 0)
    string result2 = hotel.addAnimal(dog1, 0, 0);
    output << "Case 2 (Successfully added): " << result2 << std::endl;

    // Case 3: Room is already occupied (0, 0)
    string result3 = hotel.addAnimal(cat1, 0, 0);
    output << "Case 3 (Room already occupied): " << result3 << std::endl;

    // After removing the cat, print list of animals
   
    output << "\n--- List of animals after removing the cat ---\n";
    output << hotel.printAllAnimals() << std::endl;

    //! expect ----------------------------------
    string expect = "Case 1 (Invalid position): Error: invalid position!\n"
                "Case 2 (Successfully added): (Successfully added): Successfully added an animal (Dog) to room (0, 0).\n"
                "Case 3 (Room already occupied): (Room already occupied): Error: room (0, 0) is already occupied!\n"
                "\n--- List of animals after removing the cat ---\n"
                "Room (0, 0): Dog | Name: Buddy | Arrival Date: 2025-01-10\n"
                "Room (0, 1): [Empty]\n"
                "Room (0, 2): [Empty]\n"
                "Room (0, 3): [Empty]\n"
                "Room (1, 0): [Empty]\n"
                "Room (1, 1): [Empty]\n"
                "Room (1, 2): [Empty]\n"
                "Room (1, 3): [Empty]\n"
                "Room (2, 0): [Empty]\n"
                "Room (2, 1): [Empty]\n"
                "Room (2, 2): [Empty]\n"
                "Room (2, 3): [Empty]\n"
                "Room (3, 0): [Empty]\n"
                "Room (3, 1): [Empty]\n"
                "Room (3, 2): [Empty]\n"
                "Room (3, 3): [Empty]\n\n";


    //! result ----------------------------------
    return printResult(output.str(), expect, name);
}
