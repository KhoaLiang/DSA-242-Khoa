#include "../unit_test_KTLT_petHotel.hpp"
bool UNIT_TEST_KTLT_petHotel::petHotel06() {
    string name = "petHotel06";
    stringstream output;

    PetHotel hotel(3, 3);

    Animal* dog1 = new Dog("Buddy", "2025-01-10");
    Animal* cat1 = new Cat("Mia", "2025-01-11");

    output << hotel.addAnimal(dog1, 0, 0) << std::endl;  // Thêm chó vào phòng 0,0
    output << hotel.addAnimal(cat1, 4, 4) << std::endl;  // Thêm mèo vào phòng không hợp lệ

    string expect = "(Successfully added): Successfully added an animal (Dog) to room (0, 0).\n"
                    "Error: invalid position!\n";

    return printResult(output.str(), expect, name);
}
