#include "../unit_test_KTLT_petHotel.hpp"
bool UNIT_TEST_KTLT_petHotel::petHotel01() {
string name = "petHotel01";
 //! output ----------------------------------
    stringstream output;
    
PetHotel hotel(3, 3);
// Create some pets
Animal* dog1 = new Dog("Buddy", "2025-01-10");
Animal* cat1 = new Cat("Mia", "2025-01-11");
Animal* rabbit1 = new Rabbit("Fluffy", "2025-01-12");
// Add them to the PetHotel
output << hotel.addAnimal(dog1, 0, 0) << std::endl;
output <<hotel.addAnimal(cat1, 0, 1) << std::endl;
output << hotel.addAnimal(rabbit1, 1, 0) << std::endl;
output <<"\n--- List of animals after adding ---\n";
output << hotel.printAllAnimals() << std::endl;
// Count how many "Dog"
output <<hotel.countByType("Dog") << std::endl;
// Update the rabbit's arrival date
output << hotel.updateArrivalDate(1, 0, "2025-01-15") << std::endl;
output << "\n--- List of animals after updating arrival date ---\n";
output << hotel.printAllAnimals() << std::endl;
// Remove the cat at (0, 1)
output << hotel.removeAnimal(0, 1) << std::endl;
output << "\n--- List of animals after removing the cat ---\n";
output << hotel.printAllAnimals() << std::endl;
//! expect ----------------------------------
string expect = "(Successfully added): Successfully added an animal (Dog) to room (0, 0).\n"
                "(Successfully added): Successfully added an animal (Cat) to room (0, 1).\n"
                "(Successfully added): Successfully added an animal (Rabbit) to room (1, 0).\n\n"
                "--- List of animals after adding ---\n"
                "Room (0, 0): Dog | Name: Buddy | Arrival Date: 2025-01-10\n"
                "Room (0, 1): Cat | Name: Mia | Arrival Date: 2025-01-11\n"
                "Room (0, 2): [Empty]\n"
                "Room (0, 3): [Empty]\n"
                "Room (1, 0): Rabbit | Name: Fluffy | Arrival Date: 2025-01-12\n"
                "Room (1, 1): [Empty]\n"
                "Room (1, 2): [Empty]\n"
                "Room (1, 3): [Empty]\n"
                "Room (2, 0): [Empty]\n"
                "Room (2, 1): [Empty]\n"
                "Room (2, 2): [Empty]\n"
                "Room (2, 3): [Empty]\n"
                "Room (3, 0): [Empty]\n"
                "Room (3, 1): [Empty]\n"
                "Room (3, 2): [Empty]\n"
                "Room (3, 3): [Empty]\n\n"
                "1\n"
                "Successfully updated arrival date for animal in room (1, 0).\n\n"
                "--- List of animals after updating arrival date ---\n"
                "Room (0, 0): Dog | Name: Buddy | Arrival Date: 2025-01-10\n"
                "Room (0, 1): Cat | Name: Mia | Arrival Date: 2025-01-11\n"
                "Room (0, 2): [Empty]\n"
                "Room (0, 3): [Empty]\n"
                "Room (1, 0): Rabbit | Name: Fluffy | Arrival Date: 2025-01-15\n"
                "Room (1, 1): [Empty]\n"
                "Room (1, 2): [Empty]\n"
                "Room (1, 3): [Empty]\n"
                "Room (2, 0): [Empty]\n"
                "Room (2, 1): [Empty]\n"
                "Room (2, 2): [Empty]\n"
                "Room (2, 3): [Empty]\n"
                "Room (3, 0): [Empty]\n"
                "Room (3, 1): [Empty]\n"
                "Room (3, 2): [Empty]\n"
                "Room (3, 3): [Empty]\n\n"
                "Successfully removed animal from room (0, 1).\n\n"
                "--- List of animals after removing the cat ---\n"
                "Room (0, 0): Dog | Name: Buddy | Arrival Date: 2025-01-10\n"
                "Room (0, 1): [Empty]\n"
                "Room (0, 2): [Empty]\n"
                "Room (0, 3): [Empty]\n"
                "Room (1, 0): Rabbit | Name: Fluffy | Arrival Date: 2025-01-15\n"
                "Room (1, 1): [Empty]\n"
                "Room (1, 2): [Empty]\n"
                "Room (1, 3): [Empty]\n"
                "Room (2, 0): [Empty]\n"
                "Room (2, 1): [Empty]\n"
                "Room (2, 2): [Empty]\n"
                "Room (2, 3): [Empty]\n"
                "Room (3, 0): [Empty]\n"
                "Room (3, 1): [Empty]\n"
                "Room (3, 2): [Empty]\n"
                "Room (3, 3): [Empty]\n\n";

 //! result ----------------------------------

return printResult(output.str(), expect, name);
}