#include "../unit_test_KTLT_petHotel.hpp"
bool UNIT_TEST_KTLT_petHotel::petHotel08() {
    string name = "petHotel08";
    stringstream output;

    PetHotel hotel(3, 3);
    Animal* dog1 = new Dog("Buddy", "2025-01-10");
    hotel.addAnimal(dog1, 0, 0);

    output << hotel.updateArrivalDate(0, 0, "2026-06-10") << std::endl;  // Cập nhật thành công

    string expect = "Successfully updated arrival date for animal in room (0, 0).\n";

    return printResult(output.str(), expect, name);
}
