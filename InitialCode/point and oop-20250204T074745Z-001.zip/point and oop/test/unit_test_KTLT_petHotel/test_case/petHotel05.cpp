#include "../unit_test_KTLT_petHotel.hpp"
bool UNIT_TEST_KTLT_petHotel::petHotel05() {
    string name = "petHotel05";
    stringstream output;

    PetHotel hotel(3, 3);  // Khởi tạo khách sạn với 3x3 phòng

    // Thêm 10 con thú cưng vào khách sạn
    Animal* dog1 = new Dog("Buddy", "2025-01-10");
    Animal* dog2 = new Dog("Charlie", "2025-01-11");
    Animal* dog3 = new Dog("Max", "2025-01-12");
    Animal* dog4 = new Dog("Rocky", "2025-01-13");
    Animal* dog5 = new Dog("Duke", "2025-01-14");
    
    Animal* cat1 = new Cat("Mia", "2025-01-12");
    Animal* cat2 = new Cat("Luna", "2025-01-15");
    Animal* cat3 = new Cat("Oliver", "2025-01-16");
    Animal* cat4 = new Cat("Bella", "2025-01-17");
    Animal* cat5 = new Cat("Simba", "2025-01-18");

    // Thêm thú cưng vào các phòng
    hotel.addAnimal(dog1, 0, 0);
    hotel.addAnimal(dog2, 0, 1);
    hotel.addAnimal(dog3, 0, 2);
    hotel.addAnimal(dog4, 1, 0);
    hotel.addAnimal(dog5, 1, 1);
    
    hotel.addAnimal(cat1, 1, 2);
    hotel.addAnimal(cat2, 1, 3);
    hotel.addAnimal(cat3, 2, 0);
    hotel.addAnimal(cat4, 2, 1);
    hotel.addAnimal(cat5, 2, 2);

    // Kiểm tra số lượng thú cưng của mỗi loại
    output << "Number of dogs: " << hotel.countByType("Dog") << std::endl;
    output << "Number of cats: " << hotel.countByType("Cat") << std::endl;

    string expect = "Number of dogs: 5\n"
                    "Number of cats: 5\n";

    return printResult(output.str(), expect, name);
}
