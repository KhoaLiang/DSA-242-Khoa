#include "../unit_test_KTLT_petHotel.hpp"
bool UNIT_TEST_KTLT_petHotel::petHotel07() {
    string name = "petHotel07";
    stringstream output;

    PetHotel hotel(3, 3);
    Animal* dog1 = new Dog("Buddy", "2025-01-10");

    output << hotel.updateArrivalDate(1, 1, "2026-05-02") << std::endl;  // Phòng trống

    string expect = "Error: no animal in room (1, 1)!\n";
    
    return printResult(output.str(), expect, name);
}
