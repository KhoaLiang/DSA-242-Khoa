#include "../unit_test_KTLT_petHotel.hpp"
bool UNIT_TEST_KTLT_petHotel::petHotel09() {
    string name = "petHotel09";
    stringstream output;

    PetHotel hotel(3, 3);  // Khởi tạo khách sạn 3x3

    // Tạo nhiều thú cưng
    Animal* dog1 = new Dog("Buddy", "2025-01-10");
    Animal* dog2 = new Dog("Charlie", "2025-01-11");
    Animal* dog3 = new Dog("Max", "2025-01-12");
    Animal* dog4 = new Dog("Rocky", "2025-01-13");
    Animal* dog5 = new Dog("Duke", "2025-01-14");

    Animal* cat1 = new Cat("Mia", "2025-01-11");
    Animal* cat2 = new Cat("Luna", "2025-01-12");
    Animal* cat3 = new Cat("Oliver", "2025-01-13");
    Animal* cat4 = new Cat("Bella", "2025-01-14");
    Animal* cat5 = new Cat("Simba", "2025-01-15");

    // Thêm thú cưng vào các phòng
    hotel.addAnimal(dog1, 0, 0);
    hotel.addAnimal(dog2, 0, 1);
    hotel.addAnimal(dog3, 1, 0);
    hotel.addAnimal(dog4, 1, 1);
    hotel.addAnimal(dog5, 2, 0);

    hotel.addAnimal(cat1, 0, 2);
    hotel.addAnimal(cat2, 0, 3);
    hotel.addAnimal(cat3, 1, 2);
    hotel.addAnimal(cat4, 1, 3);
    hotel.addAnimal(cat5, 2, 1);

    // Cố gắng thêm thú cưng vào phòng đã có thú cưng
    output << hotel.addAnimal(new Dog("Spike", "2025-02-01"), 0, 0) << std::endl;  // Phòng (0, 0) đã có chó
    output << hotel.addAnimal(new Cat("Chloe", "2025-02-02"), 0, 2) << std::endl;  // Phòng (0, 2) đã có mèo
    output << hotel.addAnimal(new Dog("Buster", "2025-02-03"), 2, 0) << std::endl;  // Phòng (2, 0) đã có chó

    // Kiểm tra tất cả các phòng hiện tại
    output << "\n--- Current PetHotel Rooms ---\n";
    output << hotel.printAllAnimals() << std::endl;

    string expect =  "(Room already occupied): Error: room (0, 0) is already occupied!\n"
                "(Room already occupied): Error: room (0, 2) is already occupied!\n"
                "(Room already occupied): Error: room (2, 0) is already occupied!\n"
                "\n--- Current PetHotel Rooms ---\n"
                "Room (0, 0): Dog | Name: Buddy | Arrival Date: 2025-01-10\n"
                "Room (0, 1): Dog | Name: Charlie | Arrival Date: 2025-01-11\n"
                "Room (0, 2): Cat | Name: Mia | Arrival Date: 2025-01-11\n"
                "Room (0, 3): Cat | Name: Luna | Arrival Date: 2025-01-12\n"
                "Room (1, 0): Dog | Name: Max | Arrival Date: 2025-01-12\n"
                "Room (1, 1): Dog | Name: Rocky | Arrival Date: 2025-01-13\n"
                "Room (1, 2): Cat | Name: Oliver | Arrival Date: 2025-01-13\n"
                "Room (1, 3): Cat | Name: Bella | Arrival Date: 2025-01-14\n"
                "Room (2, 0): Dog | Name: Duke | Arrival Date: 2025-01-14\n"
                "Room (2, 1): Cat | Name: Simba | Arrival Date: 2025-01-15\n"
                "Room (2, 2): [Empty]\n"
                "Room (2, 3): [Empty]\n"
                "Room (3, 0): [Empty]\n"
                "Room (3, 1): [Empty]\n"
                "Room (3, 2): [Empty]\n"
                "Room (3, 3): [Empty]\n\n";
                


    return printResult(output.str(), expect, name);
}
