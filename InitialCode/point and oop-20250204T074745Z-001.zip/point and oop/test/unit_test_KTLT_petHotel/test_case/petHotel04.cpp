#include "../unit_test_KTLT_petHotel.hpp"

bool UNIT_TEST_KTLT_petHotel::petHotel04() {
    string name = "petHotel04";
    stringstream output;  // Sử dụng stringstream để lưu kết quả

    PetHotel hotel(3, 3);  // Khởi tạo khách sạn với kích thước 3x3 (9 phòng)

    // Tạo thú cưng
    Animal* dog1 = new Dog("Buddy", "2025-01-10");
    output << hotel.addAnimal(dog1, 0, 0) << std::endl;

    // Case 1: Vị trí không hợp lệ (4, 4)
    string result1 = hotel.updateArrivalDate(4, 4, "2026-05-01");
    output << "Case 1 (Invalid position): " << result1 << std::endl;

    // Case 2: Phòng trống (1, 1) chưa có thú
    string result2 = hotel.updateArrivalDate(1, 1, "2026-05-02");
    output << "Case 2 (Empty room): " << result2 << std::endl;

    // Case 3: Cập nhật thành công (0, 0) đang có Dog
    string result3 = hotel.updateArrivalDate(0, 0, "2026-06-10");
    output << "Case 3 (Successfully updated): " << result3 << std::endl;

    // In danh sách các phòng
    output << "\n--- Current PetHotel Rooms ---\n";
    output << hotel.printAllAnimals() << std::endl;

    // Kết quả mong đợi
    string expect = "(Successfully added): Successfully added an animal (Dog) to room (0, 0).\n"
                "Case 1 (Invalid position): Error: invalid position!\n"
                "Case 2 (Empty room): Error: no animal in room (1, 1)!\n"
                "Case 3 (Successfully updated): Successfully updated arrival date for animal in room (0, 0).\n"
                "\n--- Current PetHotel Rooms ---\n"
                "Room (0, 0): Dog | Name: Buddy | Arrival Date: 2026-06-10\n"
                "Room (0, 1): [Empty]\n"
                "Room (0, 2): [Empty]\n"
                "Room (0, 3): [Empty]\n"
                "Room (1, 0): [Empty]\n"
                "Room (1, 1): [Empty]\n"
                "Room (1, 2): [Empty]\n"
                "Room (1, 3): [Empty]\n"
                "Room (2, 0): [Empty]\n"
                "Room (2, 1): [Empty]\n"
                "Room (2, 2): [Empty]\n"
                "Room (2, 3): [Empty]\n"
                "Room (3, 0): [Empty]\n"
                "Room (3, 1): [Empty]\n"
                "Room (3, 2): [Empty]\n"
                "Room (3, 3): [Empty]\n\n";


    // Kết quả thực tế
    return printResult(output.str(), expect, name);
}
